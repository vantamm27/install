#Setup zabbix agent debian/ubuntu
- Untar zabbix30-agent-deb.tar.gz
- chmod +x install-deb.sh
- Run script install-deb.sh $1
- with $1 = IP_ZABBIX_SERVER
- IP_ZABBIX_SERVER: tuong ung voi tung product theo file excel dinh kem

Ex: ./install-deb.sh 10.30.15.177,10.30.15.199
