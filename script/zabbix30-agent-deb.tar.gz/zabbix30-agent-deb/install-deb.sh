#!/bin/bash

RCol='\e[0m'    # Text Reset
Gre='\e[0;32m'
Red='\e[0;31m'
success="[$Gre OK $RCol]"
fail="[$Red Fail $RCol]"

zabbix_server=$1
prog=zabbix_agentd

function stop() {
	ps=`ps aux | grep -v grep | grep -v rsync | grep "${prog}"`
	c=`ps aux | grep -v grep | grep -v rsync | grep "${prog}" | wc -l`

	echo -n $"Stopping $prog: "
	if [ $c -gt 0 ]; then
		pids=`echo "$ps" | sed 's/  \+/ /g' | cut -d' ' -f2`
		kill -9 $pids
		echo -e $success
	fi
}

function start() {
	ps=`ps aux | grep -v grep | grep -v rsync | grep "${prog}"`
	c=`ps aux | grep -v grep | grep -v rsync | grep "${prog}" | wc -l`

	echo -n $"Starting $prog: "
	if [ $c -eq 0 ]; then
		/opt/zabbix/sbin/zabbix_agentd -c /etc/zabbix/zabbix_agentd.conf
		echo -e $success
	fi
}

function install_pkg() {
	echo "Installing zabbix agent 3.0.0 ..."
	dpkg -i zabbix30-agent_3.0.0-2.el6_amd64.deb zabbix30-agent-performance-io_3.0.0-2.el6_amd64.deb zabbix30-agent-network_3.0.0-2.el6_amd64.deb
	echo -e $success
}

function reinstall_pkg() {
	echo "Reinstalling zabbix agent 3.0.0 ..."
	dpkg -i zabbix30-agent_3.0.0-2.el6_amd64.deb zabbix30-agent-performance-io_3.0.0-2.el6_amd64.deb zabbix30-agent-network_3.0.0-2.el6_amd64.deb
	echo -e $success
}

function remove_pkg() {
	echo "Cleanup zabbix agent 2.0 & 3.0 ..."
	dpkg -r --force-remove-reinstreq --dry-run zabbix30-agent-network zabbix30-agent-performance-io zabbix30-agent
	dpkg -r --force-remove-reinstreq zabbix30-agent-network zabbix30-agent-performance-io zabbix30-agent
	echo -e $success
	
}

function check() {
	echo "Check clean 3.0 ..."
	c=`dpkg -l | grep zabbix30-agent-network | wc -l`
	if [ $c -gt 0 ]; then
		dpkg -r --force-remove-reinstreq --dry-run zabbix30-agent-network
		dpkg -r --force-remove-reinstreq zabbix30-agent-network
	fi
	
	c=`dpkg -l | grep zabbix30-agent-performance-io | wc -l`
	if [ $c -gt 0 ]; then
		dpkg -r --force-remove-reinstreq --dry-run zabbix30-agent-performance-io
		dpkg -r --force-remove-reinstreq zabbix30-agent-performance-io
	fi

	c=`dpkg -l | grep zabbix30-agent | wc -l`
	if [ $c -gt 0 ]; then
		dpkg -r --force-remove-reinstreq --dry-run zabbix30-agent
		dpkg -r --force-remove-reinstreq zabbix30-agent
	fi
	echo -e $success
}

### Step 1: Check agent exists
check

### Step 2: Install zabbix agent 3.0.0
install_pkg

### Step 3: Remove zabbix agent 3.0.0 to remove folder related with zabbix 2.0 & 3.0
remove_pkg

### Step 4: ReInstall zabbix agent 3.0.0
reinstall_pkg

### Step 5: Replace IP Zabbix Server
echo "Replacing IP Zabbix Server ..."
stop
sed -i -e "s/\(^Server=\)\(.*$\)/\1$zabbix_server/" /etc/zabbix/zabbix_agentd.conf
sed -i -e "s/\(^ServerActive=\)\(.*$\)/\1$zabbix_server/" /etc/zabbix/zabbix_agentd.conf
echo -e $success

### Restart zabbix agent
stop
start
echo "Install successful."


